package pe.edu.upeu.merytictactoe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerytictactoeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerytictactoeApplication.class, args);
	}

}
