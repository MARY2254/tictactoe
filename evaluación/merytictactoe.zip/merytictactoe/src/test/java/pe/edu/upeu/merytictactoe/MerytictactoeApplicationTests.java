package pe.edu.upeu.merytictactoe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerytictactoeApplicationTests {

	@Test
	void contextLoads() {
	}

}
